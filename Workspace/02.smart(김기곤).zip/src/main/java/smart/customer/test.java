package smart.customer;

public class test {
	public static void main(String[] args) {
		String a = "aa";
		a = "aasd";
		System.out.println(a);
	}
}
